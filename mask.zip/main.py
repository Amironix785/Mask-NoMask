import tkinter as tk
from PIL import Image, ImageTk
from tkinter import filedialog
from mlforkidsimages import MLforKidsImageProject



#---------------------------------------
def upload():
    global img1
    path_image = filedialog.askopenfilename()
    if path_image:
        img1 = ImageTk.PhotoImage(Image.open(path_image).resize((280, 330)))
        # Clear previous image
        for widget in image_frame.winfo_children():
            widget.destroy()
        demo = myproject.prediction(path_image)
        label = demo["class_name"]
        confidence = demo["confidence"]
        a = ("result: '%s' with %d%% confidence" % (label, confidence))
        l5= tk.Label(screenai,text= a)
        l5.place(x= 200 , y =450 , anchor= "center")
        # Show new image


# treat this key like a password and keep it secret!
key = "ef1d5dd0-8826-11f1-8b09-ab9ed6fefd69e7d0f9c5-0058-44d1-ac24-e577a292c1d9"

# this will train your model and might take a little while
myproject = MLforKidsImageProject(key)
myproject.train_model()

#---------------------------------------
screenai = tk.Tk()
screenai.title("Mask or No Mask")
screenai.geometry('500x700')
screenai.configure(bg="#2C3E50")
screenai.resizable(False, False)

# Header
header = tk.Label(
    screenai,
    text="😷 Mask or No Mask 🚫",
    bg="#34495E",
    fg="white",
    font=("Segoe UI", 26, "bold"),
    height=2
)
header.pack(fill="x", pady=(0, 20))

# Image Frame
image_frame = tk.Frame(
    screenai,
    bg="#ECF0F1",
    width=300,
    height=350,
    relief="solid",
    bd=2
)
image_frame.pack(pady=10)
image_frame.pack_propagate(False)

# Placeholder
placeholder = tk.Label(
    image_frame,
    text="📸 No Image",
    bg="#ECF0F1",
    fg="#7F8C8D",
    font=("Segoe UI", 14)
)
placeholder.pack(expand=True)

# Title Label
l1 = tk.Label(
    screenai,
    text="Mask or No Mask",
    bg="#2C3E50",
    fg="#ECF0F1",
    font=("Segoe UI", 20, "bold")
)
l1.pack(pady=20)

# Upload Button
b1 = tk.Button(
    screenai,
    text="📁 Upload Image",
    bg="#3498DB",
    fg="white",
    font=("Segoe UI", 13, "bold"),
    padx=25,
    pady=8,
    relief="flat",
    cursor="hand2",
    command=upload
)
b1.pack(pady=10)

screenai.mainloop()