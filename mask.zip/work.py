
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
from mlforkidsimages import MLforKidsImageProject


# ---------------------------------------
# Upload Image
def upload():
    global img1

    path_image = filedialog.askopenfilename(
        title="Choose an image",
        filetypes=[
            ("Image Files", "*.jpg *.jpeg *.png *.bmp"),
            ("All Files", "*.*")
        ]
    )

    if path_image:
        # Open and resize image
        image = Image.open(path_image)
        image.thumbnail((280, 320))

        img1 = ImageTk.PhotoImage(image)

        # Remove placeholder / previous image
        for widget in image_frame.winfo_children():
            widget.destroy()

        # Show image
        image_label = tk.Label(
            image_frame,
            image=img1,
            bg="#ECF0F1"
        )
        image_label.pack(expand=True)

        # Prediction
        demo = myproject.prediction(path_image)

        label = demo["class_name"]
        confidence = int(float(demo["confidence"]))

        # Show result
        result_text.config(
            text=f"{label}",
            fg="#27AE60" if "mask" in label.lower() else "#E74C3C"
        )

        confidence_text.config(
            text=f"Confidence: {confidence}%"
        )

        result_frame.pack(pady=(15, 10))


# ---------------------------------------
# ML for Kids Project

# Keep this key secret!
key = "ef1d5dd0-8826-11f1-8b09-ab9ed6fefd69e7d0f9c5-0058-44d1-ac24-e577a292c1d9"

myproject = MLforKidsImageProject(key)

# Train model
myproject.train_model()


# ---------------------------------------
# Main Window

screenai = tk.Tk()
screenai.title("Mask or No Mask")
screenai.geometry("500x700")
screenai.configure(bg="#2C3E50")
screenai.resizable(False, False)


# ---------------------------------------
# Header

header = tk.Label(
    screenai,
    text="😷  Mask or No Mask",
    bg="#34495E",
    fg="white",
    font=("Segoe UI", 25, "bold"),
    pady=18
)
header.pack(fill="x")


# ---------------------------------------
# Description

description = tk.Label(
    screenai,
    text="Upload a photo to detect whether a mask is being worn",
    bg="#2C3E50",
    fg="#BDC3C7",
    font=("Segoe UI", 10)
)
description.pack(pady=(15, 5))


# ---------------------------------------
# Image Frame

image_frame = tk.Frame(
    screenai,
    bg="#ECF0F1",
    width=300,
    height=350,
    relief="solid",
    bd=2
)

image_frame.pack(pady=10)
image_frame.pack_propagate(False)


# Placeholder

placeholder = tk.Label(
    image_frame,
    text="📸\n\nNo Image Selected",
    bg="#ECF0F1",
    fg="#7F8C8D",
    font=("Segoe UI", 15, "bold"),
    justify="center"
)

placeholder.pack(expand=True)


# ---------------------------------------
# Upload Button

b1 = tk.Button(
    screenai,
    text="📁  Upload Image",
    bg="#3498DB",
    fg="white",
    activebackground="#2980B9",
    activeforeground="white",
    font=("Segoe UI", 13, "bold"),
    padx=30,
    pady=10,
    relief="flat",
    bd=0,
    cursor="hand2",
    command=upload
)

b1.pack(pady=10)


# ---------------------------------------
# Result Card

result_frame = tk.Frame(
    screenai,
    bg="#FFFFFF",
    width=360,
    height=100,
    relief="flat",
    bd=0
)

result_frame.pack_propagate(False)


result_title = tk.Label(
    result_frame,
    text="RESULT",
    bg="#FFFFFF",
    fg="#7F8C8D",
    font=("Segoe UI", 9, "bold")
)

result_title.pack(pady=(10, 0))


result_text = tk.Label(
    result_frame,
    text="Waiting for image...",
    bg="#FFFFFF",
    fg="#34495E",
    font=("Segoe UI", 18, "bold")
)

result_text.pack()


confidence_text = tk.Label(
    result_frame,
    text="",
    bg="#FFFFFF",
    fg="#7F8C8D",
    font=("Segoe UI", 10)
)

confidence_text.pack(pady=(0, 8))


# ---------------------------------------
# Start

screenai.mainloop()

